﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoGIS
{
    public  class Punto
    {
       
            public string longitud { get; set; }
            public string latitud { get; set; }
        
    }
}